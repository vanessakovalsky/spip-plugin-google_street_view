<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-mailsubscribers?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'mailsubscribers_description' => 'Aanmelden e-mail distributie',
	'mailsubscribers_slogan' => 'Aanmelden e-mail distributie'
);
