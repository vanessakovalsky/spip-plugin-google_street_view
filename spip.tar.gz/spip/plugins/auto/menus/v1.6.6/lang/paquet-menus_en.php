<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-menus?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'menus_description' => 'When you are not using the plugin {{menus}}, you have to define all the menus in your templates, so that site administrators do not have direct hands on it and when they want to change something in it, they are forced to make a request to the person in charge of the templates.

In addition, when you want static links (a link to a specific article, to a specific page or to an external site) they should be hard written in the template of the menu.

The purpose of the plugin {{Menus}} is to allow you to create easily menus using an intuitive interface, directly into the private area.

{{Warning}} This plugin does not deal with the way menus are displayed. It allows their easy creation and to generate the HTML code.',
	'menus_nom' => 'Menus',
	'menus_slogan' => 'Create your own custom menus.',
	'menus_titre' => 'Menus'
);
