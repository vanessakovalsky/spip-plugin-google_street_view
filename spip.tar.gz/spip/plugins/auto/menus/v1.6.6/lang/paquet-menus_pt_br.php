<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-menus?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'menus_description' => 'Quando não se usa o plugin {{Menus}}, é necessário definir todos os seus menus nos templates, fazendo com que os administradores do site que não tenham acesso direto ao código e queiram mudar alguma coisa, sejam forçados a acionar a pessoa encarregada dos templates.

Além disso, quando é necessário criar links estáticos (um link para uma matéria específica, ou para uma página de um site externo), é necessário codificá-los na mão, no template do menu.

O objetivo do plugin {{Menus}} é facilitar a elaboração de menus através de uma interface amigável, diretamente na área privada.

{{Atenção!}} Este plugin não lida com o modo como os menus serão exibidos. Ele permite criá-los facilmente e gerar o código HTML.',
	'menus_nom' => 'Menus',
	'menus_slogan' => 'Crie os seus menus personalizados.',
	'menus_titre' => 'Menus'
);
