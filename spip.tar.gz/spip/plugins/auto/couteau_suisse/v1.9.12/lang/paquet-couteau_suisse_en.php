<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-couteau_suisse?lang_cible=en
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'couteau_suisse_description' => 'Combines in one plugin a list of small and useful new features improving the management of your SPIP site.

Each of these tools can be enabled or disabled by the user on [the plugin administration page->./?exec=admin_couteau_suisse] and manage a number of variables: click {{Configuration}}, then select the tab Couteau Suisse.

The categories are: Administration, Security, Private interface, text enhancements, Typographical shortcuts, Public display, Tags, filters, criteria.

Check out this plugin in your favorite tools: {Removes the number}, {URLs Format}, {Typographical superscript}, {Smart Quotes}, {Beautiful bullets}, {Fight against SPAM}, {Mailcrypt}, {Beautiful URLs} , {SPIP and external links...}, {Smileys}, {A summary for your articles}, {cut in pages and tabs}, etc.., etc..

Feel free to consult the articles of plugin documentation that are published on: [spip-contrib.net->http://contrib.spip.net/Le-Couteau-Suisse].

Compatibility: SPIP v1.92x, v2.x.x and v3.0',
	'couteau_suisse_slogan' => 'Lots of new and useful features for your site!'
);

?>
