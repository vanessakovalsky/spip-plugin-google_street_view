<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://www.spip.net/trad-lang/
// ** ne pas modifier le fichier **

if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// 2
	'2pts_non' => '&nbsp;:&nbsp;ket',
	'2pts_oui' => '&nbsp;:&nbsp;ya',

	// S
	'SPIP_liens:nom' => 'SPIP hag al liammo&ugrave;... diavaez',

	// A
	'acces_admin' => 'Moned merourien :',
	'action_rapide' => 'Oberiadenn brim, da implijout hepken ma ouzit ar pezh emaoc\'h oc\'h ober',
	'auteur_forum_nom' => 'Ar vaezienn "@_CS_FORUM_NOM@"'
);

?>
