<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/facteur/trunk/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// F
	'facteur_description' => 'Facteur s’occupe de la distribution des courriels au format HTML, texte ou mixte ; via SMTP ou non',
	'facteur_nom' => 'Facteur',
	'facteur_slogan' => 'Il distribue vos courriels'
);
