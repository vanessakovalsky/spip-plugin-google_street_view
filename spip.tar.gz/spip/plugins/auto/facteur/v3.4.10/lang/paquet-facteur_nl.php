<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-facteur?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// F
	'facteur_description' => 'Postbode (Facteur) houdt zich bezig met de distributie van email in HTML, tekst of gemengd formaat; al dan niet via SMTP',
	'facteur_nom' => 'Postbode',
	'facteur_slogan' => 'Hij verzendt uw mail'
);
