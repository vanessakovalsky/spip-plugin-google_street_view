<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/newsletters?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'cfg_exemple' => 'Exemplo',
	'cfg_exemple_explication' => 'Ajuda deste exemplo',
	'cfg_titre_parametrages' => 'Configurações',

	// N
	'newsletters_titre' => 'Newsletters',

	// T
	'titre_page_configurer_newsletters' => 'Configurações das Newsletters'
);
