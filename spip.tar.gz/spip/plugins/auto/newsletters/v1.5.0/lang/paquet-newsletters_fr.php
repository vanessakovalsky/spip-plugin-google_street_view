<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/newsletters/trunk/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// N
	'newsletters_description' => '',
	'newsletters_nom' => 'Newsletters',
	'newsletters_slogan' => 'Composer des Infolettres'
);
