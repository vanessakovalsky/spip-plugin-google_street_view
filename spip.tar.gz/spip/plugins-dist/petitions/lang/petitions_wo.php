<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/petitions?lang_cible=wo
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// F
	'form_pet_adresse_site' => 'Sa makkaanu dalub web', # MODIF
	'form_pet_aucune_signature' => 'Benn xaatim dëppoowul ak baat bi', # MODIF
	'form_pet_confirmation' => 'Dëgalal sa xaatim',
	'form_pet_deja_signe' => 'Xaatim nga mbind mi ba noppi.',
	'form_pet_envoi_mail_confirmation' => 'Yoonnees na ab E-bataaxal u dëggal ci @email@. war ngaa seeti sa sàqum E-bataaxal bii ngir weral sa xaatim.', # MODIF
	'form_pet_mail_confirmation' => 'Asalamaleekum yaa naan xaatim petisyoŋ @titre@.
 Joxe nga xibaar yii 
    Tur : @nom_email@
    Dalub web : @nom_site@ - @url_site@


Lu AMSOLO...
Boo bëggee weral sa xaatim, kokkal ci xàmmekaayu dal bi ci suuf boo ko deful, sa ñaan du nangu 
    @url@


Jaajëf ci seen wallusi', # MODIF
	'form_pet_nom_site2' => 'Sa makkaanu dalub web', # MODIF
	'form_pet_probleme_technique' => 'Jafe jafe xarala, xaatim yi aja gum nañu leen.',
	'form_pet_signature_validee' => 'Sa xaatim weral nañu ko. Jërëjëf !',
	'form_pet_site_deja_enregistre' => 'Aar nañu dalub web bi ba noppi ; ',
	'form_pet_url_invalide' => 'URL bi nga joxoñ werul.',
	'form_pet_votre_email' => 'Sa makkaanu emeel.',
	'form_pet_votre_nom' => 'Sa tur wall dakental ; ', # MODIF
	'form_pet_votre_site' => 'Su fekkee am nga dalub web mën nga ko joxoñ fii ci suuf.'
);

?>
