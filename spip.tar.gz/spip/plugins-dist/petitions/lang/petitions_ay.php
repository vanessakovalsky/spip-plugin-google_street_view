<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/petitions?lang_cible=ay
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_radio_activer_petition' => 'Mayiwix naktayaña',
	'bouton_radio_pas_petition' => 'Jan mayiyawimpi',
	'bouton_radio_petition_activee' => 'Mayiyaw naktata',
	'bouton_radio_supprimer_petition' => 'Mayiwi apaqaña',

	// F
	'form_pet_adresse_site' => 'Qamawimat utjawipa', # MODIF
	'form_pet_aucune_signature' => 'Janiw ni mä imt’at qillqa utjkiti aka wakt’at chimpuru', # MODIF
	'form_pet_confirmation' => 'Imt’at qillqamar iyaw sam:',
	'form_pet_deja_signe' => 'Aka saw qillqt’xtaw.',
	'form_pet_envoi_mail_confirmation' => 'Anchhitax mä iyaw sat aruskipayiri apayapxta. Iyawsamxa jisa sañatakix utjaw web aytat aka yatiyawinx uk tumpañamaw.', # MODIF
	'form_pet_mail_confirmation' => 'Kamisaki, 

Mayiw iyaw saña uk maytawa:
@titre@.

Arkir yatiyaw jasakiptaytaw:

    Suti: @nom_email@
    Qamawi: @nom_site@ - @url_site@
    @message@

YÄQATAWA...

Iyaw sawima iyaw sañatakix utjawir uñachayata ukar chinusiñamawa
(jan ukjax, iyaw sawimax janiw yäqatakaniti): 

    @url@


Arsusiwitamatxa yuspagara
   ',
	'form_pet_message_commentaire' => '¿Mä yatiyawi, mä amuyu?', # MODIF
	'form_pet_nom_site2' => 'Web qamawiman sutipa', # MODIF
	'form_pet_probleme_technique' => 'Jan wali, iyawsanakax sayt’ataw anchhichanakax.',
	'form_pet_signature_validee' => 'Iyawsamax iyaw sataxiwa. ¡Yuspajara!',
	'form_pet_site_deja_enregistre' => 'Aka qamawix qillqt’ataxiwa',
	'form_pet_url_invalide' => 'URL uka uñachayktax janiw iyaw satakiti.',
	'form_pet_votre_email' => 'Juman aruskipayiriman utjawipa',
	'form_pet_votre_nom' => 'Sutima jan ukasti sutichama', # MODIF
	'form_pet_votre_site' => 'Sitix mä Web qamawi utjtam, uñachayasmaw',

	// I
	'info_adresse_email' => 'Aka aruskipayirit utjawi:'
);

?>
