<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/medias?lang_cible=hac
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_ajouter_document' => 'سه‌رنجیو زیادکه‌رده‌',
	'bouton_ajouter_image' => 'وینیڤ زیادکه‌ره‌',
	'bouton_ajouter_image_document' => 'وینیو یا په‌روه‌ندیو زیاڎ که‌ره‌',

	// E
	'entree_dimensions' => ': ابعاد',
	'entree_titre_document' => ': عنوان سند',
	'entree_titre_image' => ': عنوان تصوير',

	// I
	'image_tourner_180' => 'چرخش °١٨٠ ',
	'image_tourner_droite' => 'چرخش ٩٠ درجه به راست',
	'image_tourner_gauche' => 'چرخش ٩٠ درجه به چپ',
	'info_document' => 'سند',
	'info_document_indisponible' => 'این سند موجود نمیباشد',
	'info_documents' => 'اسناد',
	'info_inclusion_directe' => ': گنجاندن مستقيم',
	'info_inclusion_vignette' => ': گنجاندن تصاوير كوچك شده',
	'info_installer_tous_documents' => 'تمام اسناد را مستقر كنيد',
	'info_logo_max_taille' => 'لوگوها بايد كمتر از @maxi@ باشند(اين فايل است)',
	'info_portfolio' => 'كارنامه',
	'info_telecharger' => ':با رايانه خودتان بارگذارى كنيد'
);

?>
