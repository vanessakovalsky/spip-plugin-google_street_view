<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/medias?lang_cible=is
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_ajouter_document' => 'BÆTA SKJALI VIÐ', # MODIF
	'bouton_ajouter_image' => 'BÆTA MYND VIÐ', # MODIF

	// E
	'entree_titre_document' => 'Heiti skjalsins :',
	'entree_titre_image' => 'Heiti myndarinnar :',

	// I
	'image_tourner_180' => 'Snúa um 180°',
	'image_tourner_droite' => 'Snúa um 90° til hægri',
	'image_tourner_gauche' => 'Snúa um 90° til vinstri',
	'info_document' => 'Skjal',
	'info_documents' => 'Skjöl'
);

?>
