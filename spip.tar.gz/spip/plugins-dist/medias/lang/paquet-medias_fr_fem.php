<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-medias?lang_cible=fr_fem
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'medias_description' => 'Gestion des médias de SPIP',
	'medias_slogan' => 'Gestion des médias dans SPIP'
);

?>
