<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-dump?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'dump_description' => 'نسخ احتياطي لقاعدة البيانات بتنسيق SQLite واسترجاعها',
	'dump_slogan' => 'نسخ احتياطي لقاعدة بيانات SPIP واسترجاعها'
);

?>
