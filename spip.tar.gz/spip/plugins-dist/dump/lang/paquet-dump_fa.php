<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-dump?lang_cible=fa
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'dump_description' => 'بك‌آپ و ذخيره‌سازي پايگاه داده‌ها در فرمت اس.كيو.لايت',
	'dump_slogan' => 'بك‌آپ و ذخيره سازي پايگاه داده‌‌هاي اسپيپ'
);

?>
