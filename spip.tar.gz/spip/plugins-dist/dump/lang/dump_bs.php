<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/dump?lang_cible=bs
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_restaurer_base' => 'Obnovi bazu podataka',

	// I
	'info_restauration_sauvegarde' => 'obnavljanje backup arhiva @archive@', # MODIF
	'info_sauvegarde' => 'Arhiva',
	'info_sauvegarde_reussi_02' => 'Baza je pohranjena u @archive@. Mozete se', # MODIF
	'info_sauvegarde_reussi_03' => 'vratiti uredjivanju',
	'info_sauvegarde_reussi_04' => 'vase stranice.',

	// T
	'texte_admin_tech_01' => 'Ova opcija vam omogucuje pohranjivanja sadrzaja baze u dokument koji ce biti pohranjen u  direktoriju @dossier@. Ne zaboravite sacuvati sve sto  obuhvata IMG repertoar, sto ukljucuje slike i dokumente koristene u clancima i rubrikama.', # MODIF
	'texte_admin_tech_02' => 'Paznja: Ovo pohranjivanje ne moze biti obnovljeno, OSIM na stranici koja je instalirana sa istom verzijom SPIP-a. Nije preporuceno praznjenje baze, ako namjerevate reinstalaciju backup-a nakon update-a  ... Konsultujte <a  href="@spipnet@">SPIP  dokumentaciju</a>.', # MODIF
	'texte_restaurer_base' => 'Obnoviti sadrzaj pohranjivanja baze',
	'texte_restaurer_sauvegarde' => 'Ova opcija vam omogucava obnavljanje ranije izvedenog pohranjivanja baze. U tom slucaju, dokument koji, sadrzi pohranjeni materijal, se treba nalaziti u repertoaru @dossier@. Budite oprezni sa ovom funkcijom: <b>moguce izmjene i gubitci su nepovratni.</b>', # MODIF
	'texte_sauvegarde' => 'Snimiti sadrzj baze',
	'texte_sauvegarde_base' => 'Snimiti bazu'
);

?>
