<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/vertebres?lang_cible=fr_tu
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// 1
	'1_donnee' => '1 enregistrement',

	// N
	'nb_donnees' => '@nb@ enregistrements',

	// T
	'titre_tables' => 'Tables de la base'
);

?>
