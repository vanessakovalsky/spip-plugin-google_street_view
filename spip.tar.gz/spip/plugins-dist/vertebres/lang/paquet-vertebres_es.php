<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-vertebres?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// V
	'vertebres_description' => 'Vértebras propone una forma de leer una tabla SQL indicando como argumento de página el nombre de la tabla a leer precedido de &quot;table:&quot;, por ejemplo : <code>ecrire/?exec=vertebres&table=spip_articles</code>',
	'vertebres_nom' => 'Vértebras',
	'vertebres_slogan' => 'Lector de tablas SQL'
);

?>
