<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/urls?lang_cible=it_fem
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// T
	'texte_type_urls' => 'È possibile scegliere qui sotto il modo di elaborazione dell’indirizzo delle pagine.',
	'texte_type_urls_attention' => 'Attenzione: questa impostazione funziona solamente se il file @htaccess@ è installato correttamente alla radice del sito.',
	'titre_type_urls' => 'Tipo di indirizzi URL'
);

?>
