<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_core_/plugins/urls_etendues/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// U
	'urls_description' => 'Gestion des variantes d’URL signifiantes ou non',
	'urls_slogan' => 'Gestion des variantes d’URL signifiantes ou non'
);

?>
