<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/urls?lang_cible=ro
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// T
	'texte_type_urls' => 'Puteţi alege mai jos modul de calcul a adreselor paginilor.',
	'texte_type_urls_attention' => 'Atenţie: acest reglaj nu va funcţiona corect decât dacă fişierul @htaccess@  este instalat în rădăcina site-ului.',
	'titre_type_urls' => 'Tip de adrese URL'
);

?>
