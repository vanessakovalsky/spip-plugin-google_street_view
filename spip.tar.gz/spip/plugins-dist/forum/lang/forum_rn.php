<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/forum?lang_cible=rn
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_radio_articles_futurs' => 'ku nkuru zizokurikira(ntaco bihindura kuri SQL).',
	'bouton_radio_articles_tous' => 'ku nkuru zose atakuvangura.',

	// F
	'forum' => 'Ikiyago',

	// R
	'repondre_message' => 'Kwishura kuri ubu butumwa'
);

?>
