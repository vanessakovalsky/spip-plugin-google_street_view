<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_core_/plugins/forum/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// F
	'forum_description' => 'Forum de SPIP (privé et public)',
	'forum_slogan' => 'Gestion des forums privés et publics dans SPIP'
);

?>
