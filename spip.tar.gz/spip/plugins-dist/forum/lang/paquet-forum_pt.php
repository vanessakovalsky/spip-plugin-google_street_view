<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-forum?lang_cible=pt
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// F
	'forum_description' => 'Fórum de SPIP (privado e público)',
	'forum_slogan' => 'Gestião dos fóruns públicos e privados em SPIP'
);

?>
