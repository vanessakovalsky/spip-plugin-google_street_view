<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/revisions?lang_cible=co
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'diff_para_ajoute' => 'paragrafu aghjuntu',
	'diff_para_deplace' => 'Paragrafu spiazzatu',
	'diff_para_supprime' => 'Paragrafu sguassatu',
	'diff_texte_ajoute' => 'Testu aghjuntu',
	'diff_texte_deplace' => 'Testu spiazzatu',
	'diff_texte_supprime' => 'Testu sguassatu',

	// I
	'info_historique' => 'Revisioni :',
	'info_historique_lien' => 'Vede a storia di e mudìfiche',
	'info_historique_titre' => 'Veghja di e revisioni',

	// V
	'version_deplace_rubrique' => 'Spiazzatu da <b>« @from@ »</b> à <b>« @to@ »</b>.',
	'version_initiale' => 'Versione iniziale'
);

?>
