<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/revisions?lang_cible=hu
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'diff_para_ajoute' => 'Paragráfus beszúrva',
	'diff_para_deplace' => 'Paragráfus áthelyezve',
	'diff_para_supprime' => 'Paragráfus törölve',
	'diff_texte_ajoute' => 'Szöveg beszúrva',
	'diff_texte_deplace' => 'Szöveg áthelyezve',
	'diff_texte_supprime' => 'Szöveg törölve',

	// I
	'info_historique' => 'Felülvizsgálatok :',
	'info_historique_lien' => 'A módosítások előzményei megjelenítése',
	'info_historique_titre' => 'Felülvizsgálatok megfigyelése',

	// V
	'version_initiale' => 'Eredeti verzió'
);

?>
