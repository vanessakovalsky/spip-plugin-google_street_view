<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/revisions?lang_cible=ja
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'diff_para_ajoute' => '短い記事を追加した',
	'diff_para_deplace' => '短い記事を変更した',
	'diff_para_supprime' => '短い記事を削除した',
	'diff_texte_ajoute' => 'テキストを追加した',
	'diff_texte_deplace' => 'テキストを変更した',
	'diff_texte_supprime' => '文章を削除した',

	// I
	'info_historique' => 'リビジョン（修正）:',
	'info_historique_lien' => '変更のリストを表示',
	'info_historique_titre' => '改訂（リビジョン）の追跡',

	// V
	'version_initiale' => '最初のバージョン'
);

?>
