<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/revisions?lang_cible=oc_prv
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'diff_para_ajoute' => 'Paragraf apondut',
	'diff_para_deplace' => 'Paragraf desplaçat',
	'diff_para_supprime' => 'Paragraf suprimit',
	'diff_texte_ajoute' => 'Tèxt apondut',
	'diff_texte_deplace' => 'Tèxt apondut',
	'diff_texte_supprime' => 'Tèxt suprimit',

	// I
	'info_historique' => 'Revisions:',
	'info_historique_lien' => 'Afichar l’istoric dei modificacions',
	'info_historique_titre' => 'Seguiment dei revisions',

	// V
	'version_initiale' => 'Version iniciala'
);

?>
