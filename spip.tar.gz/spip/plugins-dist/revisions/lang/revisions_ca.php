<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/revisions?lang_cible=ca
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'diff_para_ajoute' => 'Paràgraf afegit',
	'diff_para_deplace' => 'Paràgraf desplaçat',
	'diff_para_supprime' => 'Paràgraf suprimit',
	'diff_texte_ajoute' => 'Text afegit',
	'diff_texte_deplace' => 'Text desplaçat',
	'diff_texte_supprime' => 'Text suprimit',

	// I
	'info_historique' => 'Revisions:',
	'info_historique_lien' => 'Mostrar l’històric de les modificacions',
	'info_historique_titre' => 'Seguiment de les revisions',

	// V
	'version_deplace_rubrique' => 'Desplaçament de <b>« @from@ »</b> cap a <b>« @to@ »</b>.',
	'version_initiale' => 'Versió inicial'
);

?>
