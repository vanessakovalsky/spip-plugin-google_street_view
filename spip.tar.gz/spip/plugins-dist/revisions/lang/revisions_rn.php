<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/revisions?lang_cible=rn
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'diff_para_ajoute' => 'Paragraphe ajouté',
	'diff_para_deplace' => 'Paragraphe déplacé',
	'diff_para_supprime' => 'Paragraphe supprimé',
	'diff_texte_ajoute' => 'Texte ajouté',
	'diff_texte_deplace' => 'Texte déplacé',
	'diff_texte_supprime' => 'Texte supprimé'
);

?>
