<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-safehtml?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'safehtml_description' => 'Protección de los foros contra ataques de type cross-site scripting',
	'safehtml_slogan' => 'Protección de los foros contra el cross-site scripting'
);

?>
