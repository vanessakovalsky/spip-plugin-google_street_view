<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-compresseur?lang_cible=pt_br
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'compresseur_description' => 'Compressão dos css e javascript nos cabeçalhos das páginas html de <code>ecrire/</code> e/ou do site público',
	'compresseur_slogan' => 'Compressão dos css e javascript'
);

?>
