<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-compresseur?lang_cible=uk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'compresseur_description' => 'Стискає css та javascript файли для зменьшення часу завантаження. Використовується як на основному сайті, так і в його адміністративній частині <code>ecrire/</code> ',
	'compresseur_slogan' => 'Плагін для стискання CSS та Javascript файлів'
);

?>
