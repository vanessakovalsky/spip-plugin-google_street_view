<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/breves?lang_cible=nap
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// E
	'entree_breve_publiee' => 'Questa breve deve essere pubblicata?', # MODIF

	// I
	'icone_breves' => 'Nfrómme',
	'icone_nouvelle_breve' => 'Scrivite na nfrómma',
	'info_breves_02' => 'Nfrómme',
	'info_breves_valider' => 'Nfrómme ’a appruvà',
	'info_gauche_numero_breve' => 'BREVE NUMERO', # MODIF
	'item_breve_proposee' => 'Nfrómma propostata', # MODIF
	'item_breve_refusee' => 'NO - Breve rifiutata', # MODIF
	'item_breve_validee' => 'SI - Breve convalidata', # MODIF

	// L
	'logo_breve' => 'LOGO DELLA BREVE', # MODIF

	// T
	'titre_breve_publiee' => 'Nfròmma pubbrecata',
	'titre_breve_refusee' => 'Nfròmma refutata',
	'titre_langue_breve' => 'LINGUA DELLA BREVE' # MODIF
);

?>
