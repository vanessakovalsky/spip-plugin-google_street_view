<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-mots?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// M
	'mots_description' => 'Kľúčové slová a skupiny kľúčových slov',
	'mots_slogan' => 'Riadenie kľúčových slov a skupín kľúčových slov v SPIPe'
);

?>
