<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/mots?lang_cible=is
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// I
	'icone_mots_cles' => 'Lykilorð',
	'icone_supprimer_groupe_mots' => 'Eyða þessum hóp',
	'info_rubriques_liees_mot' => 'Bálkar sem tengjast þessu lykilorði',
	'info_selection_un_seul_mot_cle' => 'Þaðer ekki hægt að velja nema<b>eitt lykilorð</b> satímis í þessum hópi.', # MODIF
	'info_titre_mot_cle' => 'Nafn eða titill lykilorðs',

	// L
	'logo_mot_cle' => 'TÁKN LYKILORÐSINS'
);

?>
