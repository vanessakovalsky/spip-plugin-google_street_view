<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-porte_plume?lang_cible=ar
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// P
	'porte_plume_description' => 'الريشة هي شريط أدوات موسع لنظام SPIP يستخدم مكتبة جافاسكريبت [MarkItUp-&gt;http://markitup.jaysalvat.com/home/]',
	'porte_plume_nom' => 'الريشة',
	'porte_plume_slogan' => 'شريط أدوات لتحسين الكتابة'
);

?>
