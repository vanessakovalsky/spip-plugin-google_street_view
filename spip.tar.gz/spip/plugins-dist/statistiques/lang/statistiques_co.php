<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/statistiques?lang_cible=co
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// B
	'bouton_effacer_statistiques' => 'Sguassà e statìstiche', # MODIF

	// I
	'icone_evolution_visites' => 'Evuluzione di e vìsite<br />@visites@ vìsite',
	'icone_repartition_actuelle' => 'Vede u spartimentu attuale',
	'icone_repartition_visites' => 'Spartimentu di e vìsite',
	'icone_statistiques_visites' => 'Statìstiche',
	'info_affichier_visites_articles_plus_visites' => 'Vede e vìsite per <b>l’artìculu i più letti dipoi u principiu di u situ :</b>',
	'info_comment_lire_tableau' => 'Cumu leghje stu tavulone ?',
	'info_forum_statistiques' => 'Statìstiche di e vìsite',
	'info_popularite_2' => 'pupularità di u situ : ',
	'info_popularite_3' => 'pupularità : @popularite@ ; vìsite : @visites@',
	'info_popularite_5' => 'pupularità :',
	'info_question_vignettes_referer' => 'Cunsultendu e statìstiche, pudete puru vede in antìcipu siti d’orìgine di e vìsite',
	'info_question_vignettes_referer_oui' => 'Vede a cattura di screnu di i siti d’orìgine di e vìsite',
	'info_visites' => 'vìsite :',
	'info_visites_plus_populaires' => 'Vede e vìsite per <b>l’artìculi i più pupulari</b> è per <b>l’ùltimi artìculi pubblicati :</b>',
	'info_zoom' => 'zoom',
	'item_gerer_statistiques' => 'Gestisce e statìstiche', # MODIF

	// O
	'onglet_origine_visites' => 'Urìgine di e vìsite',
	'onglet_repartition_debut' => 'da u principiu',
	'onglet_repartition_lang' => 'Scumpartimentu per lingue',

	// R
	'resume' => 'Resume', # MODIF

	// T
	'texte_admin_effacer_stats' => 'Sta cumanda sguassa tutti i dati leati à e statìstiche di vìsite di u situ, cumpresa a pupularità di l’artìculi.',
	'texte_comment_lire_tableau' => 'U rangu di l’artìculu in a classìfica pè pupularità hè indettatu quì sopra. A pupularità di l’artìculu (stimata da u nùmeru di vìsite cutidianu ch’ellu riceverà l’artìculu s’ellu ferma uguale u rìtimu attuale di cunsultazione) è u nùmeru di vìsite ricevute dipoi u principiu sò da vede in a scatuletta chì s’apre quandu omu passa u topu sopr’à u tìtulu.',
	'texte_signification' => 'L’aste più scure riprisentanu l’entrate cumulate (per u tutale di e sotturùbbriche), l’aste più chjare u nùmeru di vìsite 
		per ogni rùbbrica.',
	'titre_evolution_visite' => 'Evuluzione di e vìsite',
	'titre_liens_entrants' => 'Lee versu u situ',
	'titre_page_statistiques' => 'Statìstiche per rùbbrica',
	'titre_page_statistiques_visites' => 'Statìstiche di vìsite'
);

?>
