<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-stats?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'stats_description' => 'Štatistiky SPIPu',
	'stats_nom' => 'Štatistiky',
	'stats_slogan' => 'Správa štatistík v SPIPe'
);

?>
