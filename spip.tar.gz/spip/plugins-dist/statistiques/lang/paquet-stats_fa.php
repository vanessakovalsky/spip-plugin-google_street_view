<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-stats?lang_cible=fa
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'stats_description' => 'آمارهاي اسپيپ',
	'stats_nom' => 'آمارها',
	'stats_slogan' => 'مديريت آمارها در اسپيپ'
);

?>
