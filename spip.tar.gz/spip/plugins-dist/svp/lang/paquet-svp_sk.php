<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-svp?lang_cible=sk
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'svp_description' => 'Tento zásuvný modul poskytuje, po prvé, aplikáciu umožňujúcu vykonávať vyhľadávania na základe viacerých kritérií, vyhľadať a zobraziť informácie o zásuvných moduloch SPIPu (funkčných moduloch, farebných motívoch i šablónach) a po druhé, nové rozhranie nastavení zásuvných modulov riadi závislosti medzi zásuvnými modulmi.',
	'svp_slogan' => 'Server na zisťovanie informácií o zásuvných moduloch a ich sťahovanie'
);

?>
