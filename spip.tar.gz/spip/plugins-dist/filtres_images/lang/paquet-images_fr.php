<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_core_/plugins/filtres_images/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// I
	'images_description' => 'Filtres de transformation d’images et de couleurs',
	'images_slogan' => 'Filtres de transformation d’images et de couleurs'
);

?>
