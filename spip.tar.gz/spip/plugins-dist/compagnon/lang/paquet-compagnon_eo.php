<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-compagnon?lang_cible=eo
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// C
	'compagnon_description' => 'La kompano proponas helpon por uzantoj dum liaj unuaj vizitoj al SPIP privata spaco.',
	'compagnon_nom' => 'Kompano',
	'compagnon_slogan' => 'Helpanto por SPIP-komencantoj'
);

?>
