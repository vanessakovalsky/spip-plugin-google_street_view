<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-sites?lang_cible=es
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'sites_description' => 'Sitios y sindicación en SPIP (privado y público)',
	'sites_slogan' => 'Administración de los sitios y de la sindicación en SPIP'
);

?>
