<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-sites?lang_cible=oc_ni_mis
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'sites_description' => 'Sit e sindicacioun en SPIP (privat et pùblicou)',
	'sites_slogan' => 'Gestioun dei sit e de la sindicacioun en SPIP'
);

?>
