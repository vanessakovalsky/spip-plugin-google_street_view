<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_core_/plugins/sites/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'sites_description' => 'Sites et syndication dans SPIP (privé et public)',
	'sites_slogan' => 'Gestion des sites et de la syndication dans SPIP'
);

?>
