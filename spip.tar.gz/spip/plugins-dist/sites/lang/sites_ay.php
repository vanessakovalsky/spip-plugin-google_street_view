<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/sites?lang_cible=ay
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'avis_echec_syndication_01' => 'Apxasiwix janiw walt’kiti: el «backend» uñacht’atax janiw yatiñjamakiti  ni mä qillqatch amuyt’aykiti.',
	'avis_echec_syndication_02' => ' Apxasiñax janiw walt’kiti: janiw ukar jak’achañjamakiti «backend» aka qamawita.',
	'avis_site_introuvable' => 'Qamawix janiw jikiskiti',
	'avis_site_syndique_probleme' => 'AMUYAM: uka qamawit apxasiwix mä jan walt’aw jiki; kunatix apnaqawix sayt’atawa. Aka qamawit q’ipit apxasiw utjawip mayamp uñjam (&lt;b&gt;@url_syndic@&lt;/b&gt;), ukhamarak yatiyaw kutt’ayañ yant’am.',
	'avis_sites_probleme_syndication' => 'Aka qamawinakax mä jan wali apxasiñaniwa',
	'avis_sites_syndiques_probleme' => 'Aka apxasit qamawinakax jan walt’anakaniwa',

	// B
	'bouton_radio_modere_posteriori' => 'qhipurunx k’achata', # MODIF
	'bouton_radio_modere_priori' => 'nayraqatax k’achata', # MODIF
	'bouton_radio_non_syndication' => 'Ni kunas apxasiwi',
	'bouton_radio_syndication' => 'Apxasiwi',

	// E
	'entree_adresse_fichier_syndication' => 'Q’ipit apxasiw utjawi:',
	'entree_description_site' => 'Qamaw uñt’ayaña',

	// F
	'form_prop_nom_site' => 'Qamawin sutipa',

	// I
	'icone_modifier_site' => 'Aka qamawi mayjt’ayaña',
	'icone_referencer_nouveau_site' => 'Mä machaq qamawi aytaña',
	'icone_voir_sites_references' => 'Aytat qamawinak uñjaña',
	'info_1_site' => '1 qamawi
',
	'info_a_valider' => '[Iyaw saña]',
	'info_bloquer' => 'jark’antaña',
	'info_bloquer_lien' => 'Aka chinu jark’antaña',
	'info_derniere_syndication' => 'Aka qamawitxa qhipa apxasiwix apasiwayiwa',
	'info_panne_site_syndique' => 'Apxasit qamawix jan waliniwa',
	'info_probleme_grave' => 'jan wali',
	'info_retablir_lien' => 'chinu askichaña',
	'info_site_attente' => 'Iyaw satañapatakix Web ukax suyaski',
	'info_site_reference' => 'Qamaw naktat aytata',
	'info_site_refuse' => 'Web qamaw janiw sata',
	'info_sites_referencer' => 'Mä qamaw aytaña',
	'info_syndication' => 'apxasiwi:',
	'info_syndication_articles' => 'qillqat(anaka)'
);

?>
