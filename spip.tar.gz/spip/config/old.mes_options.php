<?php


$GLOBALS['dossier_squelettes'] = './squelettes/demo';

?>
