<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://trad.spip.net/tradlang_module/paquet-dist?lang_cible=eo
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// D
	'dist_description' => 'Skeletaro distribuita kun SPIP 3.',
	'dist_slogan' => 'Defaŭltaj skeletoj de SPIP 3'
);

?>
