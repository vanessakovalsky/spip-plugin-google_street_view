<?php
$GLOBALS['visiteur_session']['id_auteur'] = 2;
$GLOBALS['visiteur_session']['nom'] = 'Toto';
$GLOBALS['visiteur_session']['bio'] = 'Un super auteur de démo';
$GLOBALS['visiteur_session']['email'] = 'toto@math-psud.fr';
$GLOBALS['visiteur_session']['nom_site'] = 'Super site e toto';
$GLOBALS['visiteur_session']['url_site'] = 'http://toto.com';
$GLOBALS['visiteur_session']['login'] = 'toto';
$GLOBALS['visiteur_session']['statut'] = '1comite';
$GLOBALS['visiteur_session']['webmestre'] = 'non';
$GLOBALS['visiteur_session']['maj'] = '2017-02-16 10:18:42';
$GLOBALS['visiteur_session']['pgp'] = '';
$GLOBALS['visiteur_session']['en_ligne'] = '0000-00-00 00:00:00';
$GLOBALS['visiteur_session']['source'] = 'spip';
$GLOBALS['visiteur_session']['lang'] = '';
$GLOBALS['visiteur_session']['auth'] = 'spip';
$GLOBALS['visiteur_session']['hash_env'] = 'bfc418d8f2a50e4350fc7a53fcc32175';
$GLOBALS['visiteur_session']['ip_change'] = false;
$GLOBALS['visiteur_session']['date_session'] = 1487343568;
?>
