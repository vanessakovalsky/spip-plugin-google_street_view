<?php

/*
 * Squelette : ../plugins/auto/mailsubscribers/v1.9.3/prive/style_prive_plugin_mailsubscriber.html
 * Date :      Thu, 07 Jul 2016 09:19:02 GMT
 * Compile :   Fri, 17 Feb 2017 13:58:23 GMT
 * Boucles :   
 */ 
//
// Fonction principale du squelette ../plugins/auto/mailsubscribers/v1.9.3/prive/style_prive_plugin_mailsubscriber.html
// Temps de compilation total: 0.029 ms
//

function html_b12a30f28f44fd43dbf5db710bb8dc5a($Cache, $Pile, $doublons = array(), $Numrows = array(), $SP = 0) {

	if (isset($Pile[0]["doublons"]) AND is_array($Pile[0]["doublons"]))
		$doublons = nettoyer_env_doublons($Pile[0]["doublons"]);

	$connect = '';
	$page = '


.mailsubscriber .fiche_objet h1 {word-wrap: break-word;padding-right: 85px;}
.mailsubscriber #wysiwyg .contenu_email {display:none;}
.mailsubscriber #wysiwyg .contenu_lang {margin:0.5em 0;}
.mailsubscriber #wysiwyg .contenu_lang .label {display: inline}
.mailsubscriber #wysiwyg .contenu_nom {font-weight: bold;}
.mailsubscriber #wysiwyg .contenu_nom .label {display: inline}
.mailsubscriber #wysiwyg .contenu_listes .label {display: inline}

.mailsubscriber #wysiwyg .contenu_optin {margin:1em 0;}
.mailsubscriber #wysiwyg .contenu_optin .label {display: block}
.mailsubscriber #wysiwyg .contenu_optin tt {font-family: monospace;}

.liste-objets.mailsubscribers .date {width: auto;min-width: 90px;}
.formulaire_editer_email_subscription .pull-right {float: right;}';

	return analyse_resultat_skel('html_b12a30f28f44fd43dbf5db710bb8dc5a', $Cache, $page, '../plugins/auto/mailsubscribers/v1.9.3/prive/style_prive_plugin_mailsubscriber.html');
}
?>